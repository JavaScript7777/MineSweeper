   // You lose if you put a flag in the wrong spot or reveal a bomb
import java.util.Scanner;
public class LabSweep {
      // I got tired of writing System.out.println("");
   public static void log(String a) {
      System.out.println(a);
   }
   
   public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
      int rows = 0;
      int columns = 0;
      int bombs = 0;
      do {
         try {
            log("How many rows?");
            rows = input.nextInt();
         } catch (java.util.InputMismatchException e) {
            log("Must enter an integer");
            input.nextLine();
         }
      } while (rows <= 0);
      do {
         try {
            log("Columns?");
            columns = input.nextInt();
         } catch (java.util.InputMismatchException e) {
            log("Must enter an integer");
            input.nextLine();
         }
      } while (columns <= 0);
      do {
         try {
            log("Bombs?");
            bombs = input.nextInt();
         } catch (java.util.InputMismatchException e) {
            log("Must enter an integer");
            input.nextLine();
         }
      } while (bombs <= 0);
      MineField a = new MineField(columns, rows, bombs);
      int row = 0;
      int column = 0;
      while (!a.solved) {
         try {
            a.print();
            log("row?");
            row = input.nextInt();
            log("column?");
            column = input.nextInt();
            input.nextLine();
            log("flag? \"y\" for yes \"n\" for no");
            String l = input.nextLine();
            if (l.equals("y")) {
               a.move(row-1, column-1, true);
            } else if (l.equals("n")){
               a.move(row-1, column-1, false);
            }
         } catch (java.util.InputMismatchException e) {
            log("Must enter an integer.");
            input.nextLine();
         }
      }
   }
}