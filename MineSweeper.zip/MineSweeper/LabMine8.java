public class LabMine8 {
   public static void main(String[] args) {
      MineField8 a = new MineField8(8, 8, 10);
      int[][] b = new int[8][8];
      int c = 0;
      for (int i = 0; i < 1000000000; i++) {
         a.fix();
         b = a.board();
         aa:
         for (int x = 1; x < (b.length-1); x++) {
            for (int y = 1; y < (b[x].length-1); y++) {
               if (b[x][y] == 8) {
                  c++;
                  break aa;
               }
            }
         }
      }
      System.out.println(c);
   }
}