// x, y values inverted
public class MineField8 {
   private boolean[][] board;    // array to spread mines
   private int[][] nums;        // array to add the numbers
   private int bms;
   private int a;
   private int b;
   
   public MineField8(int columns, int rows, int mines) {
      board = new boolean[rows][columns];
      nums = new int[rows][columns];
      bms = mines;
      a = rows;
      b = columns;
      fix();
   }
   
   public void fix() {
      board = new boolean[a][b];
      int x, y;
      for (int i = 0; i < bms; i++) {
         do {
            x = (int)Math.floor(Math.random()*board.length);
            y = (int)Math.floor(Math.random()*board[0].length);
         } while (board[x][y]);
         board[x][y] = true;
      }
      for (x = 0; x < board.length; x++) {
         for (y = 0; y < board[x].length; y++) {
            int a = 0;
            if (board[x][y]) {
               a = -1;
            } else {
               if (x != 0 && y != 0) {
                  if (board[x-1][y-1]) { a++; }
               }
               if (y != 0) {
                  if (board[x][y-1]) { a++; }
               }
               if (x+1 != board.length && y != 0) {
                  if (board[x+1][y-1]) { a++; }
               }
               if (x != 0) {
                  if (board[x-1][y]) { a++; }
               }
               if (x+1 != board.length) {
                  if (board[x+1][y]) { a++; }
               }
               if (x != 0 && y+1 != board[x].length) {
                  if (board[x-1][y+1]) { a++; }
               }
               if (y+1 != board[x].length) {
                  if (board[x][y+1]) { a++; }
               }
               if (x+1 != board.length && y+1 != board[x].length) {
                  if (board[x+1][y+1]) { a++; }
               }
            }
            nums[x][y] = a;
         }
      }
   }
   
   public int[][] board() {
      return nums;
   }
}