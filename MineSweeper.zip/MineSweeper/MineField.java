// x, y values inverted
public class MineField {
      // No, I did not need four arrays.
   private boolean[][] board;     // array to spread mines
   private int[][] nums;         // array to add the numbers
   private boolean[][] vis;     // array to return if a square is visible
   private boolean[][] flags;  // array for flags
   private int flag;          // num of flags
   private int cls;          // num of colomns (mostly useless)
   private int rws;         // num of rows (mostly useless)
   private int bms;        // num of bombs
   public boolean solved; // if the puzzle is solved or not
   private int moves;    // number of moves (mostly useless)
   
      // Initalize default variables
   public MineField(int columns, int rows, int mines) {
      board = new boolean[rows][columns];
      vis = new boolean[rows][columns];
      flags = new boolean[rows][columns];
      nums = new int[rows][columns];
      flag = 0;
      cls = columns;
      rws = rows;
      bms = mines;
      solved = false;
      moves = 0;
      fix(0, 0); // I would have felt bad to not leave one in here
   }
   
      // Always start in a clear field
   private void fix(int xx, int yy) {
      for (int x = 0; x < board.length; x++) {
         for (int y = 0; y < board[x].length; y++) {
            board[x][y] = false;
            vis[x][y] = false;
            flags[x][y] = false;
         }
      }
      try {
         board[xx-1][yy-1] = true;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx][yy-1] = true;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx+1][yy-1] = true;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx-1][yy] = true;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx][yy] = true;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx+1][yy] = true;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx-1][yy+1] = true;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx][yy+1] = true;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx+1][yy+1] = true;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      int x, y;
      for (int i = 0; i < bms; i++) {
         do {
            x = (int)Math.floor(Math.random()*board.length);
            y = (int)Math.floor(Math.random()*board[0].length);
         } while (board[x][y]);
         board[x][y] = true;
      }
      try {
         board[xx-1][yy-1] = false;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx][yy-1] = false;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx+1][yy-1] = false;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx-1][yy] = false;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx][yy] = false;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx+1][yy] = false;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx-1][yy+1] = false;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx][yy+1] = false;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      try {
         board[xx+1][yy+1] = false;
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {}
      for (x = 0; x < board.length; x++) {
         for (y = 0; y < board[x].length; y++) {
            int a = 0;
            if (board[x][y]) {
               a = -1;
            } else {
               if (x != 0 && y != 0) { // Top left
                  if (board[x-1][y-1]) { a++; }
               }
               if (y != 0) { // Left
                  if (board[x][y-1]) { a++; }
               }
               if (x+1 != board.length && y != 0) { // Bottom left
                  if (board[x+1][y-1]) { a++; }
               }
               if (x != 0) { // Top
                  if (board[x-1][y]) { a++; }
               }
               if (x+1 != board.length) { // Bottom
                  if (board[x+1][y]) { a++; }
               }
               if (x != 0 && y+1 != board[x].length) { // Top right
                  if (board[x-1][y+1]) { a++; }
               }
               if (y+1 != board[x].length) { // Right
                  if (board[x][y+1]) { a++; }
               }
               if (x+1 != board.length && y+1 != board[x].length) { // Bottom right
                  if (board[x+1][y+1]) { a++; }
               }
            }
            nums[x][y] = a;
         }
      }
   }
   
      // Prints in the console, reconizing visibility
   public void print() {
      for (int x = 0; x < board.length; x++) {
         System.out.print(x+1);
         accountForSpaces(x+1);
         System.out.print(":");
         for (int y = 0; y < board[x].length; y++) {
            if (vis[x][y]) {
               switch (nums[x][y]) {
                  case -1:
                     System.out.print("|x");
                     break;
                  case 0:
                     System.out.print("| ");
                     break;
                  default:
                     System.out.print("|" + nums[x][y]);
                     break;
               }
            } else {
               if (flags[x][y]) {
                  System.out.print("|!");
               } else {
                  System.out.print("|#");
               }
            }
            fitClmNumSp();
         }
         System.out.println("|");
      }
      printP2();
      System.out.println("Unflaged bombs: " + (bms-flag));
   }
   
      // Final Print ignores visibility
   public void FPrint() {
      for (int x = 0; x < board.length; x++) {
         System.out.print(x+1);
         accountForSpaces(x+1);
         System.out.print(":");
         for (int y = 0; y < board[x].length; y++) {
            if (nums[x][y] == -1) {
               if (flags[x][y]) {
                  System.out.print("|!");
               } else {
                  System.out.print("|x");
               }
            } else if (nums[x][y] > 0) {
               System.out.print("|" + nums[x][y]);
            } else {
               System.out.print("| ");
            }
            fitClmNumSp();
         }
         System.out.println("|");
      }
      printP2();
   }
   
      // I forgot what this does
   public void fitClmNumSp() {
      String length = board[0].length + "";
      int ans = length.length();
      ans--;
      for (int i = 0; i < ans; i++) {
         System.out.print(" ");
      }
   }
   
      // Add culumn numbers at the bottom
   public void printP2() {
      String l = board.length + "";
      String f = board[0].length + "";
      int j = 2 + ((f.length()+1)*board[0].length) + l.length();
      for (int i = 0; i < j; i++) {
         System.out.print("-");
      }
      System.out.println();
      for (int i = 0; i < l.length()+1; i++) {
         System.out.print(" ");
      }
      for (int y = 0; y < board[0].length; y++) {
         System.out.print("|");
         System.out.print(y+1);
         acountForSpacesClms(y+1);
      }
      System.out.println("|");
   }
   
      // I also forgot what this does
   public void acountForSpacesClms(int n) {
      String length = n + "";
      int ans = length.length();
      length = board[0].length + "";
      int ns = length.length();
      int s = ns-ans;
      for (int i = 0; i < s; i++) {
         System.out.print(" ");
      }
   }
      
      // Add spaces at the end of row numbers to allign squares
   public void accountForSpaces(int n) {
      String length = n + "";
      int ans = length.length();
      length = board.length + "";
      int ns = length.length();
      int s = ns-ans;
      for (int i = 0; i < s; i++) {
         System.out.print(" ");
      }
   }
   
      // Allows the user to actually do stuff
   public void move(int x, int y, boolean m) {
      try { // My first working try statement
         while (nums[x][y] != 0 && moves == 0) {
            fix(x-1, y-1);
         }
         moves++;
         if (board[x][y] && !m && !flags[x][y]) {
            FPrint();
            fail();
         } else {
            moves++;
            if (m) {
               flags[x][y] = true;
               flag++;
               if (!board[x][y]) {
                  FPrint();
                  fail();
                  return;
               }
            } else if (nums[x][y] == 0) {
               branch(x, y);
            } else {
               if (!flags[x][y]) {
                  vis[x][y] = true;
               }
            }
         }
         if (flag == bms) {
            completed();
         }
         if (numVis() == (cls*rws) - bms) {
            completed();
         }
      } catch (java.lang.ArrayIndexOutOfBoundsException e) {
         System.out.println("Number outside of array");
      }
   }
   
      // Returns number of visible cells that are not bombs
   public int numVis() {
      int l = 0;
      for (int x = 0; x < vis.length; x++) {
         for (int y = 0; y < vis[x].length; y++) {
            if (vis[x][y] && !board[x][y]) {
               l++;
            }
         }
      }
      return l;
   }
   
      // Runs when you fail
   public void fail() {
      solved = true; // Just to end the loop in the driver
      System.out.println("You failed");      
   }
   
      // Runs when the game is completed
   public void completed() {
      solved = true;
      System.out.println("Congratulations!!! You solved it!");
   }
   
      // When a 0 is revealed it makes all connected 0's visible
   public void branch(int x, int y) {
      vis[x][y] = true;
      if (x != 0 && y != 0) { // Top left
         if (nums[x-1][y-1] == 0 && !vis[x-1][y-1]) {
            branch(x-1, y-1);
         } else if (nums[x-1][y-1] > 0) {
            vis[x-1][y-1] = true;
         }
      }
      if (y != 0) { // Left
         if (nums[x][y-1] == 0 && !vis[x][y-1]) {
            branch(x, y-1);
         } else if (nums[x][y-1] > 0) {
            vis[x][y-1] = true;
         }
      }
      if (x+1 != board.length && y != 0) { // Bottom left
         if (nums[x+1][y-1] == 0 && !vis[x+1][y-1]) {
            branch(x+1, y-1);
         } else if (nums[x+1][y-1] > 0) {
            vis[x+1][y-1] = true;
         }
      }
      if (x != 0) { // Top
         if (nums[x-1][y] == 0 && !vis[x-1][y]) {
            branch(x-1, y);
         } else if (nums[x-1][y] > 0) {
            vis[x-1][y] = true;
         }
      }
      if (x+1 != board.length) { // Bottom
         if (nums[x+1][y] == 0 && !vis[x+1][y]) {
            branch(x+1, y);
         } else if (nums[x+1][y] > 0) {
            vis[x+1][y] = true;
         }
      }
      if (x != 0 && y+1 != board[x].length) { // Top right
         if (nums[x-1][y+1] == 0 && !vis[x-1][y+1]) {
            branch(x-1, y+1);
         } else if (nums[x-1][y+1] > 0) {
            vis[x-1][y+1] = true;
         }
      }
      if (y+1 != board[x].length) { // right
         if (nums[x][y+1] == 0 && !vis[x][y+1]) {
            branch(x, y+1);
         } else if (nums[x][y+1] > 0) {
            vis[x][y+1] = true;
         }
      }
      if (x+1 != board.length && y+1 != board[x].length) { // Bottom right
         if (nums[x+1][y+1] == 0 && !vis[x+1][y+1]) {
            branch(x+1, y+1);
         } else if (nums[x+1][y+1] > 0) {
            vis[x+1][y+1] = true;
         }
      }
   }
   
      // this was for anothor project
   public int[][] board() {
      return nums;
   }
}